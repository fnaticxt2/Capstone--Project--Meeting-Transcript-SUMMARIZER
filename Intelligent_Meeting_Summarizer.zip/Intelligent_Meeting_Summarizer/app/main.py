from fastapi import FastAPI, UploadFile, File, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import json

# Import schemas and summarization functions
from app.schemas import TranscriptInput, BatchTranscriptInput, Transcript
from app.bart_large import summarize_with_bart_large
from app.bart_large_cnn import summarize_with_bart_large_cnn

# Create FastAPI app instance
app = FastAPI(title="Intelligent Meetings Transcript Summarization APP")

# Mount the 'static' directory to serve CSS, JS, etc.
app.mount("/static", StaticFiles(directory="static"), name="static")

# Setup Jinja2 templates from the 'templates' directory
templates = Jinja2Templates(directory="templates")


# Root endpoint to show welcome message
@app.get("/")
def root():
    return {
        "message": "Welcome to the summarization API. Use /bart_large, /bart_large_cnn, or upload JSON from /ui"
    }


# Serve the web UI for uploading files and viewing summaries
@app.get("/ui")
def read_ui(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# Endpoint for summarizing a single transcript using bart_large model
@app.post("/bart_large")
def summarize_bart_large(input_data: TranscriptInput):
    summary = summarize_with_bart_large(input_data.transcripts)
    return {"summary": summary}


# Endpoint for summarizing a single transcript using bart_large_cnn model
@app.post("/bart_large_cnn")
def summarize_bart_large_cnn(input_data: TranscriptInput):
    summary = summarize_with_bart_large_cnn(input_data.transcripts)
    return {"summary": summary}


# Endpoint for batch summarization using bart_large
@app.post("/bart_large/batch")
def summarize_bart_large_batch(batch_data: BatchTranscriptInput):
    summaries = []
    for item in batch_data.batch:
        summary = summarize_with_bart_large(item.transcripts)
        summaries.append(summary)
    return {"summaries": summaries}


# Endpoint for batch summarization using bart_large_cnn
@app.post("/bart_large_cnn/batch")
def summarize_bart_large_cnn_batch(batch_data: BatchTranscriptInput):
    summaries = []
    for item in batch_data.batch:
        summary = summarize_with_bart_large_cnn(item.transcripts)
        summaries.append(summary)
    return {"summaries": summaries}


# Upload and summarize a JSON file using bart_large model
@app.post("/bart_large/batch_upload_json")
async def summarize_bart_large_batch_from_file(file: UploadFile = File(...)):
    try:
        contents = await file.read()  # Read the uploaded file
        data = json.loads(contents)   # Parse JSON content

        items = data.get("items", [])
        if not isinstance(items, list):
            raise ValueError("`items` should be a list of meetings.")

        summaries = []
        for meeting in items:
            transcripts = meeting.get("transcripts", [])
            summary = summarize_with_bart_large(transcripts)
            summaries.append(summary)

        return {"summaries": summaries}

    except Exception as e:
        # Return error if anything goes wrong
        return JSONResponse(status_code=400, content={"error": str(e)})


# Upload and summarize a JSON file using bart_large_cnn model
@app.post("/bart_large_cnn/batch_upload_json")
async def summarize_bart_large_cnn_batch_from_file(file: UploadFile = File(...)):
    try:
        contents = await file.read()  # Read uploaded file content
        data = json.loads(contents)   # Parse JSON

        items = data.get("items", [])
        if not items:
            return JSONResponse(status_code=400, content={"error": "No 'items' found in uploaded JSON."})

        summaries = []
        for item in items:
            transcripts_data = item.get("transcripts", [])
            if not transcripts_data:
                summaries.append("No transcript data available.")
                continue

            # Deserialize each transcript into a Transcript schema object
            transcripts = [Transcript(**t) for t in transcripts_data]

            # Call the summarization function
            summary = summarize_with_bart_large_cnn(transcripts)
            summaries.append(summary)

        return {"summaries": summaries}

    except json.JSONDecodeError:
        # Specific handling for invalid JSON
        return JSONResponse(status_code=400, content={"error": "Uploaded file is not valid JSON."})
    except Exception as e:
        # Generic error handling
        return JSONResponse(status_code=500, content={"error": str(e)})
