from transformers import BartTokenizer, BartForConditionalGeneration
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Path to the fine-tuned BART-large CNN model
model_path = "app/model/bart_meeting_finetuned_cnn_normal"

# Log that the model and tokenizer are being loaded
logger.info("🔁 Loading BART-large CNN model and tokenizer from %s", model_path)

# Load the tokenizer and model from the specified path
tokenizer = BartTokenizer.from_pretrained(model_path)
model = BartForConditionalGeneration.from_pretrained(model_path)

# Function to summarize a transcript using BART-large CNN
def summarize_with_bart_large_cnn(transcripts):
    logger.info("⚙️ Summarizing using BART-large CNN...")

    # Convert list of transcript turns to a single text string
    meeting_text = " ".join([
        f"{turn.speaker.lower()}: {turn.content}" for turn in transcripts
    ])

    # Remove extra whitespace from beginning and end
    input_text = meeting_text.strip()

    # Tokenize input and truncate to 1024 tokens (BART input limit)
    inputs = tokenizer(input_text, return_tensors="pt", truncation=True, max_length=1024)

    # Generate summary using BART model
    summary_ids = model.generate(
        inputs["input_ids"],
        attention_mask=inputs["attention_mask"],
        num_beams=4,              # Beam search with 4 beams for better quality
        length_penalty=2.0,       # Higher penalty encourages shorter summaries
        max_length=350,           # Allows for reasonably detailed summary
        min_length=100,           # Prevents generating very short summaries
        early_stopping=True       # Stop generation early if all beams finish
    )

    logger.info("✅ Summary generated with BART-large CNN.")

    # Decode the generated token IDs to text and return it
    return tokenizer.decode(summary_ids[0], skip_special_tokens=True)
