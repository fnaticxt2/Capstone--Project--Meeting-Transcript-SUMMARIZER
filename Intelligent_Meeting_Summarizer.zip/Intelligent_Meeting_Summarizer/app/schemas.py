from typing import List
from pydantic import BaseModel

class Transcript(BaseModel):
    speaker: str
    content: str

class TranscriptInput(BaseModel):
    transcripts: List[Transcript]


class BatchTranscriptInput(BaseModel):
    meetings: List[List[Transcript]]




