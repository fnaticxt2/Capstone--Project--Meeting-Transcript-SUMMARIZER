from transformers import BartTokenizer, BartForConditionalGeneration
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Path to the fine-tuned BART-large model
model_path = "app/model/bart_xlargesum_finetuned_normal"

# Log model loading
logger.info("🔁 Loading BART-large model and tokenizer from %s", model_path)

# Load tokenizer and model from the specified path
tokenizer = BartTokenizer.from_pretrained(model_path)
model = BartForConditionalGeneration.from_pretrained(model_path)

# Function to summarize transcripts using BART-large
def summarize_with_bart_large(transcripts):
    logger.info("⚙️ Summarizing using BART-large...")

    # Convert transcripts (Pydantic model or dict) into a single string
    meeting_text = " ".join([
        f"{(turn.speaker if hasattr(turn, 'speaker') else turn['speaker']).lower()}: "
        f"{(turn.content if hasattr(turn, 'content') else turn['content'])}"
        for turn in transcripts
    ])

    # Strip extra whitespace
    input_text = meeting_text.strip()

    # Tokenize input text (truncate to max input size of BART: 1024 tokens)
    inputs = tokenizer(input_text, return_tensors="pt", truncation=True, max_length=1024)

    # Generate summary with BART
    summary_ids = model.generate(
        inputs["input_ids"],
        attention_mask=inputs["attention_mask"],
        num_beams=4,               # Use beam search with 4 beams
        length_penalty=1.0,        # Controls summary length (higher = shorter)
        max_length=512,            # Max tokens in summary
        min_length=100,            # Minimum tokens in summary
        early_stopping=False       # Continue generating until max_length
    )

    logger.info("✅ Summary generated with BART-large.")

    # Decode and return the summary (remove special tokens like <s>, </s>)
    return tokenizer.decode(summary_ids[0], skip_special_tokens=True)
